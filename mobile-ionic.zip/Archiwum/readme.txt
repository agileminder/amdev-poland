ionic start agileminder-chatbot-mobile

ionic serve

ionic run ios

ionic emulate ios --target="iPhone-6-Plus" --livereload --consolelogs --serverlogs

# Valid values for "--target" (case sensitive):
#   iPhone-4s
#   iPhone-5
#   iPhone-5s
#   iPhone-6-Plus
#   iPhone-6
#   iPad-2
#   iPad-Retina
#   iPad-Air
#   Resizable-iPhone
#   Resizable-iPad
