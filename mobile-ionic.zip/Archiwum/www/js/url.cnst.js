(function () {
    'use strict';

    angular
        .module('emojiscale')
        .constant('url', {
            'MESSAGES_URL': 'https://agileminder-chatbot-dev.mybluemix.net/api/v1/messages'
            // 'MESSAGES_URL': 'https://localhost:8080/api/v1/messages'
        })

})();
