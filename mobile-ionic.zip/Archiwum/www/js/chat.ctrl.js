(function () {
  'use strict';

  angular
    .module('emojiscale')
    .controller('ChatController', ChatController);

  function ChatController(message, $ionicLoading) {
    var self = this;
    self.emojiValue = 5;
    self.imageUrl = '';
    self.send = send;
    self.slide = slide;

    function slide(e) {
      if(ionic.Platform.isIOS()) {
        var value = (e.target.max / e.target.offsetWidth)*(e.gesture.touches[0].screenX - e.target.offsetLeft);
        value = Math.round(value);
        if (value > 10) {
          value = 10;
        } else if (value < 1) {
          value= 1;
        }
        self.emojiValue = value;
      }
    }

    function send() {
      $ionicLoading.show();
      message.send({text: self.emojiValue + 'h'})
        .then(success, failure);
    }

    function success(response) {
      console.log('INFO ChatController.send(): Emoji value has been sent with value [' + self.emojiValue + 'h]');

      var url = response.data.imageUrl;
      self.imageUrl = 'img/' + url.substr(url.lastIndexOf('/') + 1);
      $ionicLoading.hide();
    }

    function failure(response) {
      console.log('ERROR ChatController.send(): Cannot send Emoji Value ' + JSON.stringify(response));
      $ionicLoading.hide();
    }
  }

})();
