angular.module('emojiscale', ['ionic', 'ionic.cloud'])

  .run(function ($ionicPlatform) {
    $ionicPlatform.ready(function () {
      // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
      // for form inputs)
      if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
        cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
        cordova.plugins.Keyboard.disableScroll(true);

      }
      if (window.StatusBar) {
        // org.apache.cordova.statusbar required
        StatusBar.styleDefault();
      }
    });
  })

  .config(function ($stateProvider, $urlRouterProvider, $ionicCloudProvider) {

    $ionicCloudProvider.init({
      "core": {
        "app_id": "d55e5e90"
      }
    });

    var menu = {
      name: 'menu',
      abstract: true,
      url: '/menu',
      templateUrl: 'templates/menu.tpl.html'
    };

    var signInState = {
      name: 'sign-in',
      url: '/sign-in',
      templateUrl: 'templates/sign-in.tpl.html'
    };

    var chatState = {
      name: 'menu.chat',
      url: '/chat',
      views: {
        'menuContent': {
          templateUrl: 'templates/chat.tpl.html'
        }
      }
    };

    $stateProvider
      .state(signInState)
      .state(menu)
      .state(chatState);

    $urlRouterProvider.otherwise('/sign-in');

  });
