(function () {
  'use strict';

  angular
    .module('emojiscale')
    .controller('MenuController', MenuController);

  function MenuController($ionicAuth, $ionicUser, $state) {
    var self = this;
    self.signOut = signOut;
    self.user = $ionicUser;

    function signOut() {
      var username = $ionicUser.details.name ? $ionicUser.details.name : $ionicUser.details.email;
      $ionicAuth.logout();
      if (!$ionicAuth.isAuthenticated()) {
        console.log('INFO MenuController.signOut(): User ' + username + ' signed out successfully');
      } else {
        console.log('ERROR MenuController.signOut(): User ' + username + ' cannot sign out');
      }

      $state.go('sign-in', {});
    }

  }

})();
