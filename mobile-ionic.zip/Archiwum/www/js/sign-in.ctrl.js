(function () {
  'use strict';

  angular
    .module('emojiscale')
    .controller('SignInController', SignInController);

  function SignInController($ionicAuth, $ionicUser, $ionicLoading, $state, $ionicPopup) {
    var self = this;
    self.username = '';
    self.password = '';
    self.submit = submit;
    self.signInWithSocial = signInWithSocial;

    function submit() {
      if (self.signIn) {
        signIn();
        self.signIn = false;
      } else if (self.signUp) {
        register();
        self.signUp = false;
      }
    }

    function register() {
      var details = {'email': self.username, 'password': self.password};
      $ionicLoading.show();

      $ionicAuth.signup(details).then(function () {
        $ionicAuth.login('basic', {'email': self.username, 'password': self.password});
        console.log('INFO SignInControllerNew.register(): user ' + self.username + ' is signed up');

        self.username = '';
        self.password = '';
        $state.go('menu.chat', {});
        $ionicLoading.hide();
      }, function (response) {
        alert('Cannot Sign Up', response);
        $ionicLoading.hide();
      });
      $ionicLoading.hide();
    }

    function signIn() {
      var details = {'email': self.username, 'password': self.password};
      $ionicLoading.show();

      $ionicAuth.login('basic', details).then(function () {
        console.log('INFO SignInController.signIn(): User ' + self.username + ' is signed in successfully');

        self.username = '';
        self.password = '';
        $state.go('menu.chat', {});
        $ionicLoading.hide();
      }, function (response) {
        alert('Cannot Sing In', response);
        $ionicLoading.hide();
      });

      $ionicLoading.hide();
    }

    function signInWithSocial(provider) {
      $ionicLoading.show();

      $ionicAuth.login(provider).then(function (response) {
        if (provider == 'linkedin') {
          $ionicUser.details.name = $ionicUser.social.linkedin.data.full_name;
        } else if (provider == 'twitter') {
          $ionicUser.details.name = $ionicUser.social.twitter.data.full_name;
        } else if (provider == 'facebook') {
          $ionicUser.details.name = $ionicUser.social.facebook.data.full_name;
        }

        console.log('INFO SignInController.signInWithSocial(): User ' + $ionicUser.details.name + ' is signed in successfully with ' + provider);

        self.username = '';
        self.password = '';
        $state.go('menu.chat', {});
        $ionicLoading.hide();
      }, function (response) {
        alert('Cannot Sing In', response);
        $ionicLoading.hide();
      });
    }

    function alert(title, text) {
      var alertPopup = $ionicPopup.alert({
        title: title,
        template: '<div style="text-align: center;">' + text + '</div>',
        buttons: [
          {
            type: 'red',
            text: 'OK'
          }
        ]
      });

      alertPopup.then(function (res) {
        console.log('INFO SignInController.alert(): Alert panel is shown with title [' + title + '] and text [' + text + ']');
      });

    }

  }
})();
