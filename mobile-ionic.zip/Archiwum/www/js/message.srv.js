(function () {
  'use strict';

  angular
    .module('emojiscale')
    .factory('message', message);

  function message($http, url, $ionicUser) {

    var service = {
      send: sendMessage
    };

    return service;

    function sendMessage(message) {
      var request = {
        method: 'POST',
        url: url.MESSAGES_URL,
        headers: {
          'Content-Type': 'application/json'
        },
        data: {text: message.text, userId: $ionicUser.details.name || $ionicUser.details.email}
      };

      return $http(request);
    }

  }

})();
