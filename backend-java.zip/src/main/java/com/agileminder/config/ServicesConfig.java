package com.agileminder.config;

import com.agileminder.config.bluemix.BluemixConfigHolder;
import com.agileminder.connector.WatsonConversationService;
import com.agileminder.core.*;
import com.agileminder.core.domain.EmojiMetricRepository;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.inject.Inject;
import java.io.IOException;

/**
 * @author Maciej.Scislowski@gmail.com
 */
@Configuration
public class ServicesConfig {

    @Inject
    private BluemixConfigHolder bluemixConfigHolder;
    @Inject
    private EmojiMetricRepository emojiMetricRepository;

    @Bean
    public MessageService messageService(WatsonConversationService watsonConversationService) {
        return new MessageServiceImpl(watsonConversationService, emojiScaleService(), metricService());
    }

    @Bean
    public EmojiScaleService emojiScaleService() {
        return new EmojiScaleServiceImpl(bluemixConfigHolder.getHostUrl());
    }

    @Bean
    public MetricService metricService() {
        return new MetricServiceImpl(emojiMetricRepository);
    }

}
