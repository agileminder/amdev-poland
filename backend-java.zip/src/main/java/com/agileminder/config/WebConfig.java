package com.agileminder.config;

import com.agileminder.config.bluemix.BluemixConfigHolder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

/**
 * @author Maciej.Scislowski@gmail.com
 */
@Configuration
public class WebConfig {

    @Value("${vcap.application}")
    private String vcapApplication;

    @Value("${vcap.services}")
    private String vcapServices;

    @Bean
    public RestTemplate restTemplate() {
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.getMessageConverters().add(new FormHttpMessageConverter());
        restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
        restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
        return new RestTemplate();
    }

    @Bean
    public BluemixConfigHolder bluemixConfigHolder() throws IOException {
        return new BluemixConfigHolder(vcapApplication, vcapServices);
    }



}
