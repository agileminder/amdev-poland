package com.agileminder.config;

/**
 * @author Maciej.Scislowski@gmail.com
 */
//@Configuration
//@Profile(value = {"dev", "test"})
public class CloudDataSourceConfig {

//    @Bean
//    public Cloud cloud() {
//        return new CloudFactory().getCloud();
//    }
//
//    @Bean
//    @ConfigurationProperties(prefix = "spring.datasource")
//    public DataSource dataSource() {
//        return cloud().getSingletonServiceConnector(DataSource.class, null);
//    }

}
