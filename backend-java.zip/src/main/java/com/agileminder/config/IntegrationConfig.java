package com.agileminder.config;

import com.agileminder.core.AccessTokenStoreImpl;
import com.agileminder.integration.slack.handlers.SlackEventCallbackHandler;
import com.agileminder.integration.slack.handlers.SlackUrlVerificationHandler;
import com.agileminder.core.MessageService;
import com.agileminder.integration.AccessTokenStore;
import com.agileminder.integration.slack.SlackAccessTokenHandlerImpl;
import com.agileminder.integration.slack.SlackMessageDispatcher;
import com.agileminder.integration.slack.SlackMessageDispatcherImpl;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import javax.inject.Inject;

/**
 * @author Maciej.Scislowski@gmail.com
 */
@Configuration
public class IntegrationConfig {

    @Value("${am.slack.clientId}")
    private String slackClientId;

    @Value("${am.slack.secretClient}")
    private String slackSecretClient;

    @Value("${am.slack.accessTokenUrl}")
    private String slackAccessTokenUrl;

    @Value("${am.slack.postMessageUrl}")
    private String slackPostMessageUrl;

    @Inject
    private RestTemplate restTemplate;

    @Inject
    private MessageService messageService;

    @Bean
    public SlackMessageDispatcher slackService() {
        SlackMessageDispatcher dispatcher = new SlackMessageDispatcherImpl();
        dispatcher.setSlackAccessTokenHandler(new SlackAccessTokenHandlerImpl(accessTokenStore(), restTemplate, slackAccessTokenUrl, slackClientId, slackSecretClient));

        dispatcher.addHandler(new SlackEventCallbackHandler(messageService, restTemplate, accessTokenStore(), slackPostMessageUrl));
        dispatcher.addHandler(new SlackUrlVerificationHandler());

        return dispatcher;
    }

    @Bean
    public AccessTokenStore accessTokenStore() {
        return new AccessTokenStoreImpl();
    }

}
