package com.agileminder.config.bluemix;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.io.IOException;

/**
 * @author Maciej.Scislowski@gmail.com
 */
public class BluemixConfigHolder {

    @Getter
    private String vcapApplication;
    @Getter
    private String vcapServices;
    @Getter
    private String hostUrl;

    public BluemixConfigHolder(String vcapApplication, String vcapServices) throws IOException {
        this.vcapApplication = vcapApplication;
        this.vcapServices = vcapServices;
        this.hostUrl = getHostUrlFromVcapApplication();
    }

    private String getHostUrlFromVcapApplication() throws IOException {
        JsonNode node = new ObjectMapper().readValue(vcapApplication, JsonNode.class);
        ArrayNode uris = (ArrayNode) node.get("uris");
        if (uris != null && uris.size() > 0 && uris.get(0) != null) {
            return  "http://" + uris.get(0).textValue() + "/";
        }
        return "";
    }

}
