package com.agileminder.config;

import com.agileminder.config.bluemix.BluemixConfigHolder;
import com.agileminder.connector.*;
import com.ibm.watson.developer_cloud.conversation.v1.ConversationService;
import com.ibm.watson.developer_cloud.util.CredentialUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import javax.inject.Inject;

/**
 * @author Maciej.Scislowski@gmail.com
 */
@Configuration
public class WatsonConfig {

    @Value("${am.watson.conversation.workspaceId}")
    private String workspaceId;

    @Inject
    private BluemixConfigHolder bluemixConfigHolder;

    @Bean
    public WatsonCredencialService watsonCredentialService() {
        return new WatsonCredencialServiceImpl(bluemixConfigHolder.getVcapServices());
    }

    @Bean
    @Profile("dev")
    public WatsonConversationService watsonConversationService() {
        ConversationService conversationService = new ConversationService(ConversationService.VERSION_DATE_2016_09_20);
        CredentialUtils.ServiceCredentials credentials = watsonCredentialService().getUserNameAndPassword(conversationService.getName());
        conversationService.setUsernameAndPassword(credentials.getUsername(), credentials.getPassword());
        return new WatsonConversationServiceImpl(conversationService, workspaceId);
    }

    @Bean
    @Profile("test")
    public WatsonConversationService watsonConversationServiceTest() {
        ConversationService conversationService = new ConversationService(ConversationService.VERSION_DATE_2016_09_20);
        CredentialUtils.ServiceCredentials credentials = watsonCredentialService().getUserNameAndPassword(conversationService.getName());
        conversationService.setUsernameAndPassword("bb6595ad-e07d-4430-9adb-a199dd6bc428", "o4VHOFIFjz8W");

        return new WatsonConversationServiceImpl(conversationService, workspaceId);
    }

}
