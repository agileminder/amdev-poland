package com.agileminder.connector;

import com.ibm.watson.developer_cloud.util.CredentialUtils;

/**
 * @author Maciej.Scislowski@gmail.com
 */
public interface WatsonCredencialService {
    CredentialUtils.ServiceCredentials getUserNameAndPassword(String serviceName);
}
