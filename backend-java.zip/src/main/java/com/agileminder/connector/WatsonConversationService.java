package com.agileminder.connector;

import com.agileminder.core.domain.InputMessage;
import com.agileminder.core.domain.OutputMessage;

/**
 * @author Maciej.Scislowski@gmail.com
 */
public interface WatsonConversationService {

    OutputMessage sendMessage(InputMessage inputMessage);

}
