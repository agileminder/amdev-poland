package com.agileminder.connector;

import com.agileminder.core.domain.*;
import com.ibm.watson.developer_cloud.conversation.v1.ConversationService;
import com.ibm.watson.developer_cloud.conversation.v1.model.Entity;
import com.ibm.watson.developer_cloud.conversation.v1.model.MessageRequest;
import com.ibm.watson.developer_cloud.conversation.v1.model.MessageResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Maciej.Scislowski@gmail.com
 */
public class WatsonConversationServiceImpl implements WatsonConversationService {

    private static final Logger LOG = LoggerFactory.getLogger(WatsonConversationServiceImpl.class);
    private final String workspaceId;
    private ConversationService conversationService;

    public WatsonConversationServiceImpl(ConversationService conversationService, final String workspaceId) {
        this.conversationService = conversationService;
        this.workspaceId = workspaceId;

        LOG.info("WatsonConversationService created with workspaceId: {}", workspaceId);

    }

    @Override
    public OutputMessage sendMessage(InputMessage inputMessage) {
        MessageRequest request = new MessageRequest.Builder().inputText(inputMessage.getText()).build();
        MessageResponse response = conversationService.message(workspaceId, request).execute();
        LOG.info("Watson response: " + response);

        OutputMessage outputMessage = new OutputMessage();

        outputMessage.setText(response.getText().get(0));

        String emojiScaleValue = response.getEntities().stream()
                .filter(entity -> "EmojiScale".equals(entity.getEntity())).map(Entity::getValue).collect(Collectors.joining());

        EmojiValue emojiValue;
        try {
            emojiValue = EmojiValue.valueOf("_" + emojiScaleValue.toUpperCase());
        } catch (IllegalArgumentException ex) {
            emojiValue = null;
        }

        EmojiMetric emojiMetric = new EmojiMetric();
        emojiMetric.setUserId(inputMessage.getUserId());
        emojiMetric.setTimestamp(new Date());
        emojiMetric.setEmojiValue(emojiValue);
        outputMessage.setEmojiMetric(emojiMetric);

        List<OutputMessageType> types = response.getIntents().stream().map(intent -> toOutputMessageType(intent.getIntent())).collect(Collectors.toList());
        if (types.contains(OutputMessageType.HELLO)) {
            outputMessage.setType(OutputMessageType.HELLO);
        } else {
            outputMessage.setType(OutputMessageType.ANY);
        }

        return outputMessage;
    }

    private OutputMessageType toOutputMessageType(String intent) {
        if (intent.equalsIgnoreCase("hello")) {
            return OutputMessageType.HELLO;
        } else {
            return OutputMessageType.ANY;
        }

    }

}
