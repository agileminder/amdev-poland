package com.agileminder.connector;

import com.ibm.watson.developer_cloud.util.CredentialUtils;

/**
 * @author Maciej.Scislowski@gmail.com
 */
public class WatsonCredencialServiceImpl implements WatsonCredencialService {

    public WatsonCredencialServiceImpl(String vcapServices) {
        CredentialUtils.setServices(vcapServices);
    }

    @Override
    public CredentialUtils.ServiceCredentials getUserNameAndPassword(String serviceName) {
        return CredentialUtils.getUserNameAndPassword(serviceName);
    }

}
