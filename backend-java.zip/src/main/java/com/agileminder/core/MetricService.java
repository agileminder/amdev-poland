package com.agileminder.core;

import com.agileminder.core.domain.EmojiMetric;
import com.agileminder.integration.api.MetricResponse;

import java.util.List;

/**
 * @author Maciej.Scislowski@gmail.com
 */
public interface MetricService {

    void saveEmojiMetric(EmojiMetric emojiMetric);

    List<EmojiMetric> findEmojiMetricByUserId(String userId);

    List<EmojiMetric> findAll();

}
