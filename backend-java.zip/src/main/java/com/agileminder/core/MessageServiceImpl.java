package com.agileminder.core;

import com.agileminder.connector.WatsonConversationService;
import com.agileminder.core.domain.InputMessage;
import com.agileminder.core.domain.OutputMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Maciej.Scislowski@gmail.com
 */
public class MessageServiceImpl implements MessageService {

    private static final Logger LOG = LoggerFactory.getLogger(MessageServiceImpl.class);
    private WatsonConversationService watsonConversationService;
    private EmojiScaleService emojiScaleService;
    private MetricService metricService;

    public MessageServiceImpl(WatsonConversationService watsonConversationService, EmojiScaleService emojiScaleService, MetricService metricService) {
        this.watsonConversationService = watsonConversationService;
        this.emojiScaleService = emojiScaleService;
        this.metricService = metricService;
    }

    @Override
    public OutputMessage sendMessage(String incomingMessage, String user) {
        InputMessage inputMessage = new InputMessage(incomingMessage, user);
        OutputMessage outputMessage = watsonConversationService.sendMessage(inputMessage);
        if (outputMessage.getEmojiMetric().getEmojiValue() != null) {
            metricService.saveEmojiMetric(outputMessage.getEmojiMetric());
        }


        emojiScaleService.enrichWithReplyImage(outputMessage);

        return outputMessage;
    }

}
