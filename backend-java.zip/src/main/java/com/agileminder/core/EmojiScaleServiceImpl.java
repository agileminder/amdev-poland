package com.agileminder.core;

import com.agileminder.core.domain.EmojiValue;
import com.agileminder.core.domain.ImageMeta;
import com.agileminder.core.domain.OutputMessage;
import com.agileminder.core.domain.OutputMessageType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Maciej.Scislowski@gmail.com
 */
public class EmojiScaleServiceImpl implements EmojiScaleService {

    private static final Logger LOG = LoggerFactory.getLogger(EmojiScaleServiceImpl.class);
    private static final String REPLY_FILE_SUFFIX = "HReply.gif";
    private static final String SCALE_FILE = "scale.jpg";
    private String baseUrl;

    public EmojiScaleServiceImpl(String baseUrl) {
        this.baseUrl = baseUrl;
        LOG.info("BASE_URL " + baseUrl);
    }

    @Override
    public void enrichWithReplyImage(OutputMessage outputMessage) {
        EmojiValue emojiValue = outputMessage.getEmojiMetric().getEmojiValue();

        ImageMeta imageMeta = new ImageMeta();
        outputMessage.setImageMeta(imageMeta);

        if (OutputMessageType.HELLO == outputMessage.getType()) {
            imageMeta.setImageTitle("Emoji Scale");
            imageMeta.setImageUrl(baseUrl + SCALE_FILE);
            return;
        }

        if (emojiValue == null) {
            imageMeta.setImageTitle("");
            imageMeta.setImageUrl("");
            return;
        }

        switch (emojiValue) {
            case _1H:
                imageMeta.setImageTitle(EmojiValue._1H.name());
                imageMeta.setImageUrl(baseUrl + "1" + REPLY_FILE_SUFFIX);
                break;
            case _2H:
                imageMeta.setImageTitle(EmojiValue._2H.name());
                imageMeta.setImageUrl(baseUrl + "2" + REPLY_FILE_SUFFIX);
                break;
            case _3H:
                imageMeta.setImageTitle(EmojiValue._3H.name());
                imageMeta.setImageUrl(baseUrl + "3" + REPLY_FILE_SUFFIX);
                break;
            case _4H:
                imageMeta.setImageTitle(EmojiValue._4H.name());
                imageMeta.setImageUrl(baseUrl + "4" + REPLY_FILE_SUFFIX);
                break;
            case _5H:
                imageMeta.setImageTitle(EmojiValue._5H.name());
                imageMeta.setImageUrl(baseUrl + "5" + REPLY_FILE_SUFFIX);
                break;
            case _6H:
                imageMeta.setImageTitle(EmojiValue._6H.name());
                imageMeta.setImageUrl(baseUrl + "6" + REPLY_FILE_SUFFIX);
                break;
            case _7H:
                imageMeta.setImageTitle(EmojiValue._7H.name());
                imageMeta.setImageUrl(baseUrl + "7" + REPLY_FILE_SUFFIX);
                break;
            case _8H:
                imageMeta.setImageTitle(EmojiValue._8H.name());
                imageMeta.setImageUrl(baseUrl + "8" + REPLY_FILE_SUFFIX);
                break;
            case _9H:
                imageMeta.setImageTitle(EmojiValue._9H.name());
                imageMeta.setImageUrl(baseUrl + "9" + REPLY_FILE_SUFFIX);
                break;
            case _10H:
                imageMeta.setImageTitle(EmojiValue._10H.name());
                imageMeta.setImageUrl(baseUrl + "10" + REPLY_FILE_SUFFIX);
                break;
            default:
        }
    }

}
