package com.agileminder.core;

import com.agileminder.core.domain.OutputMessage;

/**
 * @author Maciej.Scislowski@gmail.com
 */
public interface EmojiScaleService {

    void enrichWithReplyImage(OutputMessage outputMessage);

}
