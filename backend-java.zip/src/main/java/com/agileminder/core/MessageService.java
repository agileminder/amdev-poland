package com.agileminder.core;

import com.agileminder.core.domain.InputMessage;
import com.agileminder.core.domain.OutputMessage;

/**
 * @author Maciej.Scislowski@gmail.com
 */
public interface MessageService {

    OutputMessage sendMessage(String incomingMessage, String user);

}
