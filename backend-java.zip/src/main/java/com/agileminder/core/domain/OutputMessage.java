package com.agileminder.core.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Maciej.Scislowski@gmail.com
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class OutputMessage {

    private String text;

    private EmojiMetric emojiMetric;
    private ImageMeta imageMeta;
    private OutputMessageType type;

}
