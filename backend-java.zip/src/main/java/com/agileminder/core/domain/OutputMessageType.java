package com.agileminder.core.domain;

/**
 * @author Maciej.Scislowski@gmail.com
 */
public enum OutputMessageType {

    HELLO, ANY;

}
