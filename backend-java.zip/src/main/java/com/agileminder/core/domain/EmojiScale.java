package com.agileminder.core.domain;

import lombok.Data;

import java.util.List;

/**
 * @author Maciej.Scislowski@gmail.com
 */
@Data
public class EmojiScale {

    private List<EmojiValue> emojiValues;

}
