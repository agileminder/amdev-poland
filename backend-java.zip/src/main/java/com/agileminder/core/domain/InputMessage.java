package com.agileminder.core.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Maciej.Scislowski@gmail.com
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class InputMessage {

    private String text;
    private String userId;

}
