package com.agileminder.core.domain;

import lombok.Getter;

/**
 * @author Maciej.Scislowski@gmail.com
 */
@Getter
public enum EmojiValue {

    _1H("1H"), _2H("2H"), _3H("3H"), _4H("4H"), _5H("5H"), _6H("6H"), _7H("7H"), _8H("8H"), _9H("9H"), _10H("10H");

    private String label;

    EmojiValue(String label) {
        this.label = label;
    }

}