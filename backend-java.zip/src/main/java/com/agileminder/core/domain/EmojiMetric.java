package com.agileminder.core.domain;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.util.Date;

/**
 * @author Maciej.Scislowski@gmail.com
 */
@Data
@Entity
public class EmojiMetric {

    @Id
    @GeneratedValue
    private Long id;
    private String userId;
    private Date timestamp;
    private EmojiValue emojiValue;

}
