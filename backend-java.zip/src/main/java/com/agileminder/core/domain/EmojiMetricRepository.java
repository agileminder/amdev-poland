package com.agileminder.core.domain;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Maciej.Scislowski@gmail.com
 */
@Repository
public interface EmojiMetricRepository extends CrudRepository<EmojiMetric, Long> {

    List<EmojiMetric> findByUserId(String userId);

}
