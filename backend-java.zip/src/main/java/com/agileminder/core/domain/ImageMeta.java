package com.agileminder.core.domain;

import lombok.Data;

/**
 * @author Maciej.Scislowski@gmail.com
 */
@Data
public class ImageMeta {

    private String imageTitle;
    private String imageUrl;

}
