package com.agileminder.core;

import com.agileminder.core.domain.EmojiMetric;
import com.agileminder.core.domain.EmojiMetricRepository;
import com.agileminder.core.domain.EmojiValue;
import com.agileminder.integration.api.MetricResponse;

import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * @author Maciej.Scislowski@gmail.com
 */
public class MetricServiceImpl implements MetricService {

    private EmojiMetricRepository emojiMetricRepository;

    public MetricServiceImpl(EmojiMetricRepository emojiMetricRepository) {
        this.emojiMetricRepository = emojiMetricRepository;
    }

    @Override
    public void saveEmojiMetric(EmojiMetric emojiMetric) {
        emojiMetricRepository.save(emojiMetric);
    }

    @Override
    public List<EmojiMetric> findEmojiMetricByUserId(String userId) {
        return emojiMetricRepository.findByUserId(userId);
    }

    @Override
    public List<EmojiMetric> findAll() {
        return (List<EmojiMetric>) emojiMetricRepository.findAll();
    }

}
