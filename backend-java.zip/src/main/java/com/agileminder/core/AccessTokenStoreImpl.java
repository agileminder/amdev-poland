package com.agileminder.core;

import com.agileminder.integration.AccessTokenStore;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Maciej.Scislowski@gmail.com
 */
public class AccessTokenStoreImpl implements AccessTokenStore {

    private Map<String, String> tokens = new HashMap<>();

    @Override
    public void storeToken(String id, String token) {
        tokens.put(id, token);
    }

    @Override
    public String getTokenById(String id) {
        return tokens.get(id);
    }

}
