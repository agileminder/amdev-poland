package com.agileminder.integration;

/**
 * @author Maciej.Scislowski@gmail.com
 */
public interface AccessTokenStore {
    
    void storeToken(String id, String token);

    String getTokenById(String id);
    
}
