package com.agileminder.integration.slack;

/**
 * @author Maciej.Scislowski@gmail.com
 */
public interface SlackAccessTokenHandler {

    void handleAccessToken(String authorizationCode);

}
