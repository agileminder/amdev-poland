package com.agileminder.integration.slack.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * @author Maciej.Scislowski@gmail.com
 */
//@Data
public class MessageRequest {

//    @JsonProperty
//    private String token;
//    @JsonProperty
//    private String channel;
//    @JsonProperty
//    private String text;


}
