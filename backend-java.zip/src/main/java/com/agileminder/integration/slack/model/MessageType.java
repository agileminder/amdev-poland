package com.agileminder.integration.slack.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Maciej.Scislowski@gmail.com
 */
public enum MessageType {

    @JsonProperty("event_callback")
    EVENT_CALLBACK,
    @JsonProperty("url_verification")
    URL_VERIFICATION

}
