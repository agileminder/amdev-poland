package com.agileminder.integration.slack;

import com.agileminder.integration.AccessTokenStore;
import com.agileminder.integration.slack.model.AccessTokenResponse;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

/**
 * @author Maciej.Scislowski@gmail.com
 */
public class SlackAccessTokenHandlerImpl implements SlackAccessTokenHandler {

    private AccessTokenStore accessTokenStore;
    private RestTemplate restTemplate;
    private String url;
    private String clientId;
    private String clientSecret;

    public SlackAccessTokenHandlerImpl(AccessTokenStore accessTokenStore, RestTemplate restTemplate, String url, String clientId, String clientSecret) {
        this.accessTokenStore = accessTokenStore;
        this.restTemplate = restTemplate;
        this.url = url;
        this.clientId = clientId;
        this.clientSecret = clientSecret;
    }

    @Override
    public void handleAccessToken(String authorizationCode) {
        MultiValueMap<String, String> parameters = new LinkedMultiValueMap<>();
        parameters.add("client_id", clientId);
        parameters.add("client_secret", clientSecret);
        parameters.add("code", authorizationCode);
        AccessTokenResponse accessTokenResponse = restTemplate.postForObject(url, parameters, AccessTokenResponse.class);
        accessTokenStore.storeToken(accessTokenResponse.getTeamId(), accessTokenResponse.getBot().getBotAccessToken());
    }

}
