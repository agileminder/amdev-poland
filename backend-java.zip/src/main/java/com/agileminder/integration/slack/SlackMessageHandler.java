package com.agileminder.integration.slack;

import com.agileminder.integration.slack.model.MessageType;

import java.io.IOException;

/**
 * @author Maciej.Scislowski@gmail.com
 */
public interface SlackMessageHandler {

    MessageType getMessageType();

    String handleMessage(String requestBody) throws IOException;

}
