package com.agileminder.integration.slack.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * @author Maciej.Scislowski@gmail.com
 */
@Data
public class AccessTokenResponse {

    @JsonProperty
    private boolean ok;
    @JsonProperty("access_token")
    private String accessToken;
    @JsonProperty
    private String scope;
    @JsonProperty("user_id")
    private String userId;
    @JsonProperty("team_name")
    private String teamName;
    @JsonProperty("team_id")
    private String teamId;
    @JsonProperty
    private Bot bot;

}