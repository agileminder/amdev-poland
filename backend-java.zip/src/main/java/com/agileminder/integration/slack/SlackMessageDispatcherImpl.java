package com.agileminder.integration.slack;

import com.agileminder.integration.slack.model.MessageType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.CaseFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Maciej.Scislowski@gmail.com
 */
public class SlackMessageDispatcherImpl implements SlackMessageDispatcher {

    private static final Logger LOG = LoggerFactory.getLogger(SlackMessageDispatcherImpl.class);
    private static final ObjectMapper mapper = new ObjectMapper();
    private SlackAccessTokenHandler accessTokenHandler;
    private List<SlackMessageHandler> handlers = new ArrayList<>();

    @Override
    public void exchangeAuthorizationCodeForAccessToken(String authorizationCode) {
        accessTokenHandler.handleAccessToken(authorizationCode);
    }

    @Override
    public String dispatch(final String requestBody) throws IOException {
        JsonNode jsonRequestBody = mapper.readValue(requestBody, JsonNode.class);
        String typeValue = jsonRequestBody.get("type").textValue();
        MessageType type = MessageType.valueOf(CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.UPPER_UNDERSCORE, typeValue));

        return handlers.stream().filter(handler -> handler.getMessageType() == type)
                .map(handler -> {
                    try {
                        return handler.handleMessage(requestBody);
                    } catch (IOException e) {
                        throw new UncheckedIOException(e);
                    }
                }).collect(Collectors.joining());
    }

    @Override
    public void addHandler(SlackMessageHandler handler) {
        this.handlers.add(handler);
    }

    @Override
    public void setSlackAccessTokenHandler(SlackAccessTokenHandler slackAccessTokenHandler) {
        this.accessTokenHandler = slackAccessTokenHandler;
    }

}
