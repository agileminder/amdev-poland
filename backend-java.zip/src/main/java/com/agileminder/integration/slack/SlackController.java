package com.agileminder.integration.slack;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import java.io.IOException;

/**
 * @author Maciej.Scislowski@gmail.com
 */
@Controller
public class SlackController {

    private static final Logger LOG = LoggerFactory.getLogger(SlackController.class);

    @Inject
    private SlackMessageDispatcher slackMessageDispatcher;

    @PostMapping(value = "/api/slack", produces = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    @ResponseBody
    public ResponseEntity<String> messages(@RequestBody String requestBody) throws IOException {
        LOG.info("Slack request body: " + requestBody);
        String responseBody = slackMessageDispatcher.dispatch(requestBody);
        LOG.info("Slack response body: " + responseBody);

        return ResponseEntity.ok(responseBody);
    }

    @GetMapping("/api/slack")
    public String token(@RequestParam("code") String authorizationCode) {
        slackMessageDispatcher.exchangeAuthorizationCodeForAccessToken(authorizationCode);
        return "redirect:/slack";
    }

    @GetMapping("/slack")
    public String showInstallation() {
        return "slack";
    }

}
