package com.agileminder.integration.slack;

import java.io.IOException;

/**
 * @author Maciej.Scislowski@gmail.com
 */
public interface SlackMessageDispatcher {

    void addHandler(SlackMessageHandler handler);

    void setSlackAccessTokenHandler(SlackAccessTokenHandler slackAccessTokenHandler);

    String dispatch(String requestBody) throws IOException;

    void exchangeAuthorizationCodeForAccessToken(String authorizationCode);
}
