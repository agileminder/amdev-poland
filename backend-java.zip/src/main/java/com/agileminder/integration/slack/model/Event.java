package com.agileminder.integration.slack.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * @author Maciej.Scislowski@gmail.com
 */
@Data
public class Event {

    @JsonProperty
    private String type;
    @JsonProperty
    private String user;
    @JsonProperty
    private String text;
    @JsonProperty
    private String ts;
    @JsonProperty
    private String channel;
    @JsonProperty("event_ts")
    private String eventTs;

}