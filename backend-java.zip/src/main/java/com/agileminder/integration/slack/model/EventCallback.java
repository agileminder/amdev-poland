package com.agileminder.integration.slack.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * @author Maciej.Scislowski@gmail.com
 */
@Data
public class EventCallback {

    @JsonProperty
    private String token;
    @JsonProperty("team_id")
    private String teamId;
    @JsonProperty("api_app_id")
    private String apiAppId;
    @JsonProperty
    private Event event;
    @JsonProperty("type")
    private MessageType messageType;
    @JsonProperty("authed_users")
    private List<String> authedUsers;

}