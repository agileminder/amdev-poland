package com.agileminder.integration.slack.handlers;

import com.agileminder.core.MessageService;
import com.agileminder.core.domain.OutputMessage;
import com.agileminder.integration.AccessTokenStore;
import com.agileminder.integration.slack.SlackMessageHandler;
import com.agileminder.integration.slack.model.EventCallback;
import com.agileminder.integration.slack.model.MessageType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Maciej.Scislowski@gmail.com
 */
public class SlackEventCallbackHandler implements SlackMessageHandler {

    private static final Logger LOG = LoggerFactory.getLogger(SlackEventCallbackHandler.class);
    private static final ObjectMapper mapper = new ObjectMapper();
    private MessageService messageService;
    private RestTemplate restTemplate;
    private AccessTokenStore accessTokenStore;
    private String url;

    public SlackEventCallbackHandler(MessageService messageService, RestTemplate restTemplate, AccessTokenStore accessTokenStore, String url) {
        this.messageService = messageService;
        this.restTemplate = restTemplate;
        this.accessTokenStore = accessTokenStore;
        this.url = url;
    }

    @Override
    public MessageType getMessageType() {
        return MessageType.EVENT_CALLBACK;
    }

    @Override
    public String handleMessage(String requestBody) throws IOException {
        if (isBotMessage(requestBody)) {
            LOG.info("Ignored bot message: " + requestBody);
            return null;
        }

        EventCallback eventCallback = mapper.readValue(requestBody, EventCallback.class);
        OutputMessage outgoingMessage = messageService.sendMessage(eventCallback.getEvent().getText(), eventCallback.getEvent().getUser());

        List<Map<String, String>> attachments = new ArrayList<>();

        Map<String, String> attachement1 = new HashMap<>();
        attachments.add(attachement1);
        attachement1.put("title", outgoingMessage.getImageMeta().getImageTitle());
        attachement1.put("image_url", outgoingMessage.getImageMeta().getImageUrl());

        String channel = eventCallback.getEvent().getChannel();
        String token = accessTokenStore.getTokenById(eventCallback.getTeamId());

        MultiValueMap<String, String> parameters = new LinkedMultiValueMap<>();
        parameters.add("token", token);
        parameters.add("channel", channel);
        parameters.add("text", outgoingMessage.getText());
        parameters.add("attachments", mapper.writeValueAsString(attachments));

        LOG.info("Slack outgoing message: " + parameters);

        ResponseEntity<String> responseEntity = restTemplate.postForEntity(url, parameters, String.class);
        return responseEntity.getBody();
    }

    private boolean isBotMessage(String requestBody) throws IOException {
        JsonNode jsonRequestBody = mapper.readValue(requestBody, JsonNode.class);
        JsonNode jsonSubtype= jsonRequestBody.get("event").get("subtype");
        if (jsonSubtype != null) {
            String subtypeValue = jsonSubtype.textValue();
            if ("bot_message".equals(subtypeValue)) {
                return true;
            }
        }
        return false;
    }

}
