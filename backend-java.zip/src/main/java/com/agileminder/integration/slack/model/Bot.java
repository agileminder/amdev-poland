package com.agileminder.integration.slack.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * @author Maciej.Scislowski@gmail.com
 */
@Data
public class Bot {

    @JsonProperty("bot_user_id")
    private String botUserId;
    @JsonProperty("bot_access_token")
    private String botAccessToken;

}