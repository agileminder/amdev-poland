package com.agileminder.integration.slack.handlers;

import com.agileminder.integration.slack.SlackMessageHandler;
import com.agileminder.integration.slack.model.MessageType;
import com.agileminder.integration.slack.model.UrlVerification;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;

/**
 * @author Maciej.Scislowski@gmail.com
 */
public class SlackUrlVerificationHandler implements SlackMessageHandler {

    private static final ObjectMapper mapper = new ObjectMapper();

    @Override
    public MessageType getMessageType() {
        return MessageType.URL_VERIFICATION;
    }

    @Override
    public String handleMessage(String requestBody) throws IOException {
        UrlVerification urlVerification = mapper.readValue(requestBody, UrlVerification.class);
        return urlVerification.getChallengeJson().toString();
    }
}
