package com.agileminder.integration.slack.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Data;

/**
 * @author Maciej.Scislowski@gmail.com
 */
@Data
public class UrlVerification {

    private static final String CHALLENGE_PROPERTY = "challenge";
    private static final ObjectMapper mapper = new ObjectMapper();
    @JsonProperty
    private String token;
    @JsonProperty
    private String challenge;
    @JsonProperty("type")
    private MessageType messageType;

    public ObjectNode getChallengeJson() {
        ObjectNode json = mapper.createObjectNode();
        json.put(UrlVerification.CHALLENGE_PROPERTY, this.challenge);
        return json;
    }
}
