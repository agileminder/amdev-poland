package com.agileminder.integration.api;

import com.agileminder.core.MessageService;
import com.agileminder.core.domain.OutputMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Inject;
import java.io.IOException;

/**
 * @author Maciej.Scislowski@gmail.com
 */
@RestController
public class MessageController {

    private static final Logger LOG = LoggerFactory.getLogger(MessageController.class);
    @Inject
    private MessageService messageService;

    @PostMapping(value = "/api/v1/messages")
    public ResponseEntity<MessageResponse> messages(@RequestBody MessageRequest messageRequest) throws IOException {
        LOG.info("REST API request body: " + messageRequest);
        OutputMessage outgoingMessage = messageService.sendMessage(messageRequest.getText(), messageRequest.getUserId());

        MessageResponse messageResponse = new MessageResponse(outgoingMessage.getText(), outgoingMessage.getImageMeta().getImageUrl());
        LOG.info("REST API response body: " + messageResponse);

        return ResponseEntity.ok(messageResponse);
    }

}
