package com.agileminder.integration.api;

/**
 * @author Maciej.Scislowski@gmail.com
 */
public class MetricRequest {
}
