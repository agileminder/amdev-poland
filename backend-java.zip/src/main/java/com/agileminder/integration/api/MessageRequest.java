package com.agileminder.integration.api;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * @author Maciej.Scislowski@gmail.com
 */
@Data
public class MessageRequest {

    @JsonProperty
    private String userId;
    @JsonProperty
    private String text;

}
