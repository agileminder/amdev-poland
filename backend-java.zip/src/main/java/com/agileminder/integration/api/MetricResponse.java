package com.agileminder.integration.api;

import com.agileminder.core.domain.EmojiMetric;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author Maciej.Scislowski@gmail.com
 */
@Data
@AllArgsConstructor
public class MetricResponse {

    private String userId;
    private Date timestamp;
    private String emojiValue;

}
