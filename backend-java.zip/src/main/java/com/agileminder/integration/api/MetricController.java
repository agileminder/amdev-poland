package com.agileminder.integration.api;

import com.agileminder.core.MetricService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Maciej.Scislowski@gmail.com
 */
@RestController
public class MetricController {

    private static final Logger LOG = LoggerFactory.getLogger(MetricController.class);
    @Inject
    private MetricService metricService;

    @GetMapping(value = "/api/v1/metrics/{userId}")
    public ResponseEntity<List<MetricResponse>> metricsByUserId(@PathVariable String userId) {
        List<MetricResponse> metricResponses = metricService.findEmojiMetricByUserId(userId).stream().map(metric ->
                new MetricResponse(metric.getUserId(), metric.getTimestamp(), metric.getEmojiValue().getLabel()))
                .collect(Collectors.toList());
        return ResponseEntity.ok(metricResponses);
    }

    @GetMapping(value = "/api/v1/metrics")
    public ResponseEntity<List<MetricResponse>> metrics() {
        List<MetricResponse> metricResponses = metricService.findAll().stream().map(metric ->
                new MetricResponse(metric.getUserId(), metric.getTimestamp(), metric.getEmojiValue().getLabel()))
                .collect(Collectors.toList());
        return ResponseEntity.ok(metricResponses);
    }

}
