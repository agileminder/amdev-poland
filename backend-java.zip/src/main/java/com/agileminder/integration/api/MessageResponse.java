package com.agileminder.integration.api;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author Maciej.Scislowski@gmail.com
 */
@Data
@AllArgsConstructor
public class MessageResponse {

    @JsonProperty
    private String text;
    @JsonProperty
    private String imageUrl;

}
