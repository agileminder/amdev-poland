(function () {
    'use strict';

    angular
        .module('app')
        .controller('ChatController', ChatController);

    function ChatController($state, $timeout, $location, $anchorScroll, session, message) {
        var self = this;
        self.waiting = false;
        self.username = session.getUsername();
        self.messages = [];
        self.message = {
            userId: self.username,
            text: ''
        };

        self.signOut = signOut;
        self.send = send;

        function signOut() {
            session.setUsername('');
            $state.go('sign-in', {});
        }

        function send() {
            self.messages.push(self.message);
            self.messages.push({userId: 'AgileMinder'});
            self.waiting = true;

            $timeout(function () {
                $location.hash('end');
                $anchorScroll();
            });

            message.send(self.message)
                .then(success, failure);
            self.message = {
                userId: self.username,
                text: ''
            };
        }

        function success(response) {
            self.messages.pop();
            self.messages.push({userId: 'AgileMinder', text: response.data.text, imageUrl: response.data.imageUrl});
            self.waiting = false;
            $timeout(function () {
                $location.hash('end');
                $anchorScroll();
            });
        }

        function failure(response) {
            self.waiting = false;
            window.alert('failure ' + response);
        }
    }

})();