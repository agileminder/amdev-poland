(function () {
    'use strict';

    angular
        .module('app')
        .controller('SignInController', SignInController);

    function SignInController($state, session) {
        var self = this;
        self.username = '';
        self.password = '';
        self.signIn = signIn;

        function signIn() {
            session.setUsername(self.username);
            $state.go('chat', {});
        }
    }

})();