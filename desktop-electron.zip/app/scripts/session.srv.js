(function () {
    'use strict';

    angular
        .module('app')
        .factory('session', session);

    function session() {
        var username = '';
        var service = {
            getUsername: getUsername,
            setUsername: setUsername
        };
        return service;

        function getUsername() {
            return username;
        }

        function setUsername(user) {
            username = user;
        }

    }

})();