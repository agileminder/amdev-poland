(function () {
    'use strict';

    angular
        .module('app')
        .factory('message', message);

    function message($http, url, session) {
        var service = {
            send: sendMessage
        };
        return service;

        function sendMessage(message) {
            var request = {
                method: 'POST',
                url: url.MESSAGES_URL,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: {text: message.text, userId: session.getUsername()}
            };

            return $http(request);
        }

    }

})();