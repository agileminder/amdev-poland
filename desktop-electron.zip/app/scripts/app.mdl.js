(function () {
    'use strict';

    angular
        .module('app', ['ngMaterial', 'ui.router'])

        .config(function ($stateProvider, $urlRouterProvider) {
                var signInState = {
                    name: 'sign-in',
                    url: '/sign-in',
                    templateUrl: 'scripts/sign-in.tpl.html'
                };
                var chatState = {
                    name: 'chat',
                    url: '/chat',
                    templateUrl: 'scripts/chat.tpl.html'
                };

                $stateProvider.state(signInState);
                $stateProvider.state(chatState);
                $urlRouterProvider.otherwise('/sign-in');
            }
        );

})();
