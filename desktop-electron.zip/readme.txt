#initial
sudo npm install electron-packager --save-dev
sudo npm install electron --save-dev

#build platform versions
npm run build

#remove build
rm -rf MyApp-darwin-x64/

#develop
npm run start